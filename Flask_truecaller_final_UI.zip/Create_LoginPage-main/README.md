# Create_LoginPage
This project will give you an exemple of login page using Flask. 

1. First Step 
copy the current project using : git clone https://github.com/Faouzizi/Create_LoginPage.git

2. Second step
go to this directory using shell command. 
cd Create_LoginPage

3. Install python packages
Install all python packages using the following command : pip install -r requirements.txt

4. Run Flask App
Now you can run the Flask app using the folowing command : python3 main.py

Enjoy => if you have any question you can contact me :) 

<a href="https://www.buymeacoffee.com/faoel" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/default-orange.png" alt="Buy Me A Coffee" height="41" width="174"></a>
